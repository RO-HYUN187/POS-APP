using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;

namespace POINT_SALE_DEMO
{
    public class Urun
    {
        public int Id { get; set; }
        public string UrunAdi { get; set; } = string.Empty;
        public decimal Fiyat { get; set; }
        public int Stok { get; set; }
    }

    public class SepetItem
    {
        public string UrunAdi { get; set; } = string.Empty;
        public int Adet { get; set; }
        public decimal BirimFiyat { get; set; }
        public decimal Toplam => Adet * BirimFiyat;
    }

    public partial class Form1 : Form
    {
        public static string DbPath = "market.db";
        public static string ConnectionString = $"Data Source={DbPath}";

        private List<SepetItem> sepet = new List<SepetItem>();

        private ComboBox cmbUrunler = new ComboBox();
        private NumericUpDown numAdet = new NumericUpDown();
        private Button btnEkle = new Button();
        private Button btnSatisYap = new Button();
        private Button btnYonetim = new Button();
        private DataGridView dgvSepet = new DataGridView();
        private Label lblToplam = new Label();

        public Form1()
        {
            InitializeComponent();
            VeritabaniHazirla();
            FormTasariminiYukle();
            UrunListesiniYukle();
        }

        private void InitializeComponent() { }

        // SQLite Veritabanı ve Tablo Oluşturma
        private void VeritabaniHazirla()
        {
            using (var connection = new SqliteConnection(ConnectionString))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = @"
                    CREATE TABLE IF NOT EXISTS Urunler (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        UrunAdi TEXT NOT NULL UNIQUE,
                        Fiyat DECIMAL NOT NULL,
                        Stok INTEGER NOT NULL
                    );";
                command.ExecuteNonQuery();

                // Eğer tablo boşsa varsayılan örnek ürünler ekle
                command.CommandText = "SELECT COUNT(*) FROM Urunler";
                long count = (long)(command.ExecuteScalar() ?? 0);
                if (count == 0)
                {
                    command.CommandText = @"
                        INSERT INTO Urunler (UrunAdi, Fiyat, Stok) VALUES 
                        ('Ekmek', 10.00, 50),
                        ('Süt 1L', 35.50, 20),
                        ('Çikolata', 25.00, 100);";
                    command.ExecuteNonQuery();
                }
            }
        }

        // SQLite'tan Bütün Ürünleri Çekme
        public static List<Urun> UrunleriGetir()
        {
            var urunler = new List<Urun>();
            using (var connection = new SqliteConnection(ConnectionString))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "SELECT Id, UrunAdi, Fiyat, Stok FROM Urunler";
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        urunler.Add(new Urun
                        {
                            Id = reader.GetInt32(0),
                            UrunAdi = reader.GetString(1),
                            Fiyat = reader.GetDecimal(2),
                            Stok = reader.GetInt32(3)
                        });
                    }
                }
            }
            return urunler;
        }

        private void FormTasariminiYukle()
        {
            this.Text = "Market POS - Satış Ekranı (SQLite)";
            this.Size = new Size(800, 500);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lblUrun = new Label { Text = "Ürün Seç:", Location = new Point(20, 20), AutoSize = true };
            cmbUrunler = new ComboBox { Location = new Point(85, 17), Width = 150, DropDownStyle = ComboBoxStyle.DropDownList };

            Label lblAdet = new Label { Text = "Adet:", Location = new Point(250, 20), AutoSize = true };
            numAdet = new NumericUpDown { Location = new Point(290, 17), Width = 60, Minimum = 1, Maximum = 100, Value = 1 };

            btnEkle = new Button { Text = "Sepete Ekle", Location = new Point(360, 15), Width = 100 };
            btnEkle.Click += BtnEkle_Click;

            btnYonetim = new Button { Text = "Ürün Yönetimi", Location = new Point(650, 15), Width = 110 };
            btnYonetim.Click += (s, e) => {
                new Form2().ShowDialog();
                UrunListesiniYukle();
            };

            dgvSepet = new DataGridView
            {
                Location = new Point(20, 60),
                Size = new Size(740, 320),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true
            };

            lblToplam = new Label
            {
                Text = "Toplam: 0,00 TL",
                Font = new Font("Arial", 14, FontStyle.Bold),
                Location = new Point(20, 400),
                AutoSize = true
            };

            btnSatisYap = new Button
            {
                Text = "Satışı Onayla",
                Location = new Point(610, 395),
                Size = new Size(150, 40),
                BackColor = Color.LightGreen
            };
            btnSatisYap.Click += BtnSatisYap_Click;

            this.Controls.AddRange(new Control[] {
                lblUrun, cmbUrunler, lblAdet, numAdet, btnEkle,
                btnYonetim, dgvSepet, lblToplam, btnSatisYap
            });

            this.AcceptButton = btnEkle;
        }

        public void UrunListesiniYukle()
        {
            var urunler = UrunleriGetir();
            cmbUrunler.DataSource = null;
            cmbUrunler.DataSource = urunler.Select(u => u.UrunAdi).ToList();
        }

        private void BtnEkle_Click(object? sender, EventArgs e)
        {
            if (cmbUrunler.SelectedItem == null)
            {
                MessageBox.Show("Lütfen bir ürün seçin!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string secilenUrunAdi = cmbUrunler.SelectedItem.ToString() ?? "";
            var urun = UrunleriGetir().FirstOrDefault(u => u.UrunAdi == secilenUrunAdi);

            if (urun == null) return;

            int istenenAdet = (int)numAdet.Value;
            if (urun.Stok < istenenAdet)
            {
                MessageBox.Show($"Yetersiz stok! Mevcut stok: {urun.Stok}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var mevcutSepetItem = sepet.FirstOrDefault(s => s.UrunAdi == urun.UrunAdi);
            if (mevcutSepetItem != null)
            {
                mevcutSepetItem.Adet += istenenAdet;
            }
            else
            {
                sepet.Add(new SepetItem
                {
                    UrunAdi = urun.UrunAdi,
                    Adet = istenenAdet,
                    BirimFiyat = urun.Fiyat
                });
            }

            SepetGuncelle();
        }

        private void SepetGuncelle()
        {
            dgvSepet.DataSource = null;
            dgvSepet.DataSource = sepet;
            lblToplam.Text = $"Toplam: {sepet.Sum(x => x.Toplam):C2}";
        }

        private void BtnSatisYap_Click(object? sender, EventArgs e)
        {
            if (!sepet.Any())
            {
                MessageBox.Show("Sepet boş!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var connection = new SqliteConnection(ConnectionString))
            {
                connection.Open();
                foreach (var item in sepet)
                {
                    var command = connection.CreateCommand();
                    command.CommandText = "UPDATE Urunler SET Stok = Stok - @adet WHERE UrunAdi = @adi";
                    command.Parameters.AddWithValue("@adet", item.Adet);
                    command.Parameters.AddWithValue("@adi", item.UrunAdi);
                    command.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Satış başarıyla tamamlandı ve SQLite veritabanına işlendi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            sepet.Clear();
            SepetGuncelle();
        }
    }
}

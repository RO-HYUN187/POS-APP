﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;

namespace POINT_SALE_DEMO
{
    public partial class Form2 : Form
    {
        private DataGridView dgvUrunler = new DataGridView();
        private TextBox txtAd = new TextBox();
        private TextBox txtFiyat = new TextBox();
        private TextBox txtStok = new TextBox();
        private Button btnEkle = new Button();
        private Button btnGuncelle = new Button();
        private Button btnSil = new Button();

        public Form2()
        {
            InitializeComponent();
            FormTasariminiYukle();
            ListeyiGuncelle();
        }

        private void InitializeComponent() { }

        private void FormTasariminiYukle()
        {
            this.Text = "Ürün Yönetim Paneli (SQLite)";
            this.Size = new Size(600, 500);
            this.StartPosition = FormStartPosition.CenterParent;

            dgvUrunler = new DataGridView
            {
                Location = new Point(20, 20),
                Size = new Size(540, 220),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };
            dgvUrunler.CellClick += DgvUrunler_CellClick;

            Label l1 = new Label { Text = "Ürün Adı:", Location = new Point(20, 260), AutoSize = true };
            txtAd = new TextBox { Location = new Point(80, 257), Width = 120 };

            Label l2 = new Label { Text = "Fiyat:", Location = new Point(220, 260), AutoSize = true };
            txtFiyat = new TextBox { Location = new Point(260, 257), Width = 80 };

            Label l3 = new Label { Text = "Stok:", Location = new Point(360, 260), AutoSize = true };
            txtStok = new TextBox { Location = new Point(400, 257), Width = 80 };

            btnEkle = new Button { Text = "Yeni Ürün Ekle", Location = new Point(20, 310), Size = new Size(250, 40), BackColor = Color.LightBlue };
            btnEkle.Click += BtnEkle_Click;

            btnGuncelle = new Button { Text = "Seçili Ürünü Güncelle", Location = new Point(310, 310), Size = new Size(250, 40), BackColor = Color.Aquamarine };
            btnGuncelle.Click += BtnGuncelle_Click;

            btnSil = new Button { Text = "Seçili Ürünü Sil", Location = new Point(20, 360), Size = new Size(540, 40), BackColor = Color.LightCoral };
            btnSil.Click += BtnSil_Click;

            this.Controls.AddRange(new Control[] {
                dgvUrunler, l1, txtAd, l2, txtFiyat, l3, txtStok, btnEkle, btnGuncelle, btnSil
            });
        }

        private void ListeyiGuncelle()
        {
            dgvUrunler.DataSource = null;
            dgvUrunler.DataSource = Form1.UrunleriGetir();
        }

        private void DgvUrunler_CellClick(object? sender, DataGridViewCellEventArgs e)
        {
            if (dgvUrunler.CurrentRow != null)
            {
                var secilen = (Urun)dgvUrunler.CurrentRow.DataBoundItem;
                txtAd.Text = secilen.UrunAdi;
                txtFiyat.Text = secilen.Fiyat.ToString();
                txtStok.Text = secilen.Stok.ToString();
            }
        }

        private void BtnEkle_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtAd.Text))
            {
                MessageBox.Show("Ürün adı boş olamaz!");
                return;
            }

            if (decimal.TryParse(txtFiyat.Text, out decimal fiyat) && int.TryParse(txtStok.Text, out int stok))
            {
                using (var connection = new SqliteConnection(Form1.ConnectionString))
                {
                    connection.Open();
                    var command = connection.CreateCommand();
                    command.CommandText = "INSERT INTO Urunler (UrunAdi, Fiyat, Stok) VALUES (@adi, @fiyat, @stok)";
                    command.Parameters.AddWithValue("@adi", txtAd.Text);
                    command.Parameters.AddWithValue("@fiyat", fiyat);
                    command.Parameters.AddWithValue("@stok", stok);

                    try
                    {
                        command.ExecuteNonQuery();
                        MessageBox.Show("Ürün SQLite veritabanına eklendi!");
                        ListeyiGuncelle();
                        FormuTemizle();
                    }
                    catch (SqliteException)
                    {
                        MessageBox.Show("Bu isimde bir ürün zaten var!");
                    }
                }
            }
            else
            {
                MessageBox.Show("Fiyat veya Stok alanını kontrol edin!");
            }
        }

        private void BtnGuncelle_Click(object? sender, EventArgs e)
        {
            if (dgvUrunler.CurrentRow == null)
            {
                MessageBox.Show("Lütfen tablodan bir ürün seçin!");
                return;
            }

            var secilen = (Urun)dgvUrunler.CurrentRow.DataBoundItem;

            if (decimal.TryParse(txtFiyat.Text, out decimal yeniFiyat) && int.TryParse(txtStok.Text, out int yeniStok))
            {
                using (var connection = new SqliteConnection(Form1.ConnectionString))
                {
                    connection.Open();
                    var command = connection.CreateCommand();
                    command.CommandText = "UPDATE Urunler SET UrunAdi = @adi, Fiyat = @fiyat, Stok = @stok WHERE Id = @id";
                    command.Parameters.AddWithValue("@adi", txtAd.Text);
                    command.Parameters.AddWithValue("@fiyat", yeniFiyat);
                    command.Parameters.AddWithValue("@stok", yeniStok);
                    command.Parameters.AddWithValue("@id", secilen.Id);
                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Ürün başarıyla güncellendi!");
                ListeyiGuncelle();
                FormuTemizle();
            }
            else
            {
                MessageBox.Show("Geçerli fiyat ve stok girin!");
            }
        }

        private void BtnSil_Click(object? sender, EventArgs e)
        {
            if (dgvUrunler.CurrentRow != null)
            {
                var silinecek = (Urun)dgvUrunler.CurrentRow.DataBoundItem;
                using (var connection = new SqliteConnection(Form1.ConnectionString))
                {
                    connection.Open();
                    var command = connection.CreateCommand();
                    command.CommandText = "DELETE FROM Urunler WHERE Id = @id";
                    command.Parameters.AddWithValue("@id", silinecek.Id);
                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Ürün silindi!");
                ListeyiGuncelle();
                FormuTemizle();
            }
        }

        private void FormuTemizle()
        {
            txtAd.Clear();
            txtFiyat.Clear();
            txtStok.Clear();
        }
    }
}